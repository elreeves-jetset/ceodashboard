# myCEO Dashboard update

Replace your existing index.html with the included version. manifest.json is included unchanged. Keep your existing sw.js and icon files alongside them; those files were not attached to the source conversation. Service worker registration and manifest references are unchanged. Offline installation and cache updates could not be verified without sw.js and the icons.

The recurring schedule now uses the requested wording: three tasks on each weekday and one shared three-task checklist for Saturday/Sunday. Weekend tasks checked on Saturday stay checked on Sunday. Each new week starts fresh.

Daily cards have no pillar requirements, week objectives, or extra trial-reel checklist. The month tracker uses three tasks per day (the weekend dots reflect the same checklist). The weekly review counts 18 unique tasks for a complete week. Historical four-task completion remains visible separately. Other tabs and the main myceodash_v3 state are preserved.

New completion uses ceotasks_done_v1_DATE, with Saturday's date identifying the weekend. ceotasks_start_v1 records the first-use date (Saturday when first opened Sunday). Old ceo4done_DATE and other records are retained; old category ticks never complete unrelated new tasks. The existing explicit month-reset action still clears that month's tracker, including its new checklist records. Export/import includes the new keys.

Overdue tasks look back two calendar days, without suppressing tasks by category. Saturday tasks do not become overdue on Sunday. The new system does not create overdue tasks before its first-use date.

Verified in Chrome: card count and Monday wording; three-task schedules throughout a month; mark done and reload; old data preservation; month progress; shared weekend completion; weekend overdue behavior; 18-task weekly totals; export/import; all tab navigation; mobile overflow and desktop/mobile card appearance. No JavaScript errors occurred. PWA offline behavior remains unverified because the service worker was not supplied.

## Daily suggestion choices

The “Let’s move something forward” suggestions now offer YES (the existing add-to-this-week action) and NO (hide this suggestion today). Dismissals use studio_review_no_YYYY-MM-DD in localStorage, based on the local calendar date, and identify each suggestion by its source and text. They survive refresh and are included in existing export/import support. The next local day ignores the previous day’s dismissals. Focus checkboxes and other dashboard behavior are unchanged.

Verified in Chrome: YES acceptance and completion, NO affects only its suggestion, refresh and tab navigation persistence, local-midnight reset, mobile layout, and the existing full dashboard regression suite.
